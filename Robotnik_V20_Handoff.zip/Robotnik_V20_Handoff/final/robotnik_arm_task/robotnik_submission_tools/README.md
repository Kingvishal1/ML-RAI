# Robotnik V20: Circular Drop Zone (integration handoff)

The current working reference is `robotnik_sensor_bc_v2/robotnik_expert_controller.py` launched by `robotnik_submission_tools/run_expert.sh`. The **existing pretrained base and arm checkpoints** control approach and the provided **V4 neural checkpoint** controls finger closure/holding. Expert controllers perform ball carry, release-site selection within a circular zone, release, and return-home. **This is a hybrid reference implementation, not an end-to-end learned policy.**

Use a 0.50 m radius circle centred at (3.0, 3.5), with a conservative release region and verified gravity-driven ball landing inside the circle. Before integration or training, obtain reproducible V20 PASS logs from the Ubuntu simulator (the user reports V20 worked; full log has not yet been provided here).

## Quick start (Ubuntu comp0245)

```bash
cd ~/Desktop/UCL/ML/ML-RAI-affan-latest/final/robotnik_arm_task
conda activate comp0245
export PYTHONPATH="$PWD:$HOME/Desktop/UCL/ML/RoboEnv/simulation_and_control${PYTHONPATH:+:$PYTHONPATH}"
bash robotnik_submission_tools/run_expert.sh --target 2.5 3.0 1.0 --dropoff_xy 3.0 3.5 --drop_zone_radius 0.50 2>&1 | tee robotnik_v20_zone.log
grep -E 'V20_CIRCULAR_DROP_RESULT|V19_ARM_RETURN_HOME|V9_GROUND_PLACEMENT_RESULT|V8_RELEASE_RESULT' robotnik_v20_zone.log
```

Use `--headless` for rendering performance. `run_expert.sh` supports overriding base/arm checkpoint paths by passing `--base_checkpoint other.pt --arm_checkpoint other.pt` after the standard arguments. Do not delete or overwrite teammate weights. The original `.pt` files are not included in this handoff; copy/install your own from the team's authorized source.

## Ownership and merge boundaries

- **Single PyBullet process:** The team must have only one simulator stepping physics and one motor-command owner. Do not run `robotnik_expert_controller.py` concurrently with another simulator.
- **Teammate pretrained models:** Do not edit checkpoints. Their base/arm and avoidance policy can be plugged into the shared orchestrator (see `integration/MERGE_CONTRACT.md`); no assertion that they are already wired together.
- **ML policy:** V4 finger checkpoint SHA-256 is captured in `MODEL_STATUS.json`; do not silently swap it. Original approach checkpoints are external dependencies.
- **Expert reference:** The fully self-contained *controller source* and helper modules are versioned. Student BC placement modules and scripts are included for future work but are not claimed trained or physically verified.
- **Do not train from failing episodes.** Capture verified `.npz` demonstrations and log provenance.

## Verification

```bash
python robotnik_sensor_bc_v2/test_drop_zone_control.py
python robotnik_sensor_bc_v2/test_ground_placement_control.py
python robotnik_sensor_bc_v2/test_reachability_feedback.py
python robotnik_submission_tools/integration/test_bridge.py
```

All static checks and pure controller-level tests can run without opening a PyBullet GUI. They do not replace a physics rollout or integrated evaluation.
