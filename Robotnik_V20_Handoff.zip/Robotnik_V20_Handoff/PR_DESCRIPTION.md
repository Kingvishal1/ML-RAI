# Robotnik V20 — circular drop zone, physical grasp and return-home (integration handoff)

## Summary
- Provide the complete source of the working standalone V20 reference controller with a 0.50 m radius placement zone, physical release checks and arm return-home.
- Preserve the V4 residual BC finger checkpoint (hash recorded) and existing pretrained base/arm interfaces.
- Keep the standalone expert path separate from team navigation/avoidance models. Teammates should merge through a single owner for PyBullet and motor commands.

## Testing
- 19 pure-Python unit tests (5 zone, 5 lowering, 6 reachability, 3 navigation bridge) pass in this package.
- Python sources compile.
- User reports V20 standalone worked; attach actual Ubuntu `robotnik_v20_zone.log` and note test conditions before a physics success claim.
- Integrated teammate-model tests pending.

## Follow-up for teammates
- Connect avoidance output through `robotnik_navigation_bridge.py` and shared arbitration; don't launch two simulators.
- Supply the existing or updated trained base/arm checkpoints separately and compare model hashes.
- Re-run the expert end-to-end, then assess any student-only policies separately.

**No trained teammate base/arm checkpoint is added, replaced, or deleted by this change.**
