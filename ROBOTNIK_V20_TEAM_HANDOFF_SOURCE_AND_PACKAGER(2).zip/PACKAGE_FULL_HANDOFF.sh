#!/usr/bin/env bash
# Run from the ROOT of your robotnik_arm_task checkout after unpacking code ZIP.
set -euo pipefail
cd "$(dirname "$0")"
python - <<'PYCODE'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path.cwd()
output=root/'ROBOTNIK_V20_TEAM_COMPLETE.zip'
required=[
'robotnik_sensor_bc_v2/robotnik_v20_one_ball_release_student.py',
'robotnik_sensor_bc_v2/learned_release_student.py',
'robotnik_sensor_bc_v2/placement_policy.py',
'robotnik_sensor_bc_v2/sensor_bc_v4.py',
'robotnik_sensor_bc_v2/drop_zone_control.py',
'robotnik_sensor_bc_v2/candidate_bc_policy.py',
'robotnik_sensor_bc_v2/ground_placement_control.py',
'robotnik_sensor_bc_v2/reachability_feedback.py',
'robotnik_submission_tools/train_v20_corrective.py',
'robotnik_submission_tools/train_v20_one_ball_release.py',
'RUN_COLLECT_RELEASE_V2.sh','RUN_TRAIN_RELEASE_V2.sh',
'RUN_TEST_RELEASE_V2.sh','RUN_TEST_STEP4_RETURN_HOME.sh',
'robotnik_sensor_bc_v2/grasp_sensor_residual_bc_v4.npz',
'060_bc_base_gelu_e70_h512_l3_16min_working.pt',
'051_bc_arm_gelu_e70_h512_l3_3min_working.pt',
'v20_release_v2_checkpoint_dir.txt',
]
marker=root/'v20_release_v2_checkpoint_dir.txt'
if marker.is_file():
 d=Path(marker.read_text().strip())
 if d.is_absolute():
  candidate=d/'release_student.npz'
  if candidate.is_file():
   required.append(str(candidate))
 else:
  required.append(str(d/'release_student.npz'))
else:
 required.append('trained_v20_release_v2_20261104_235509/release_student.npz')
missing=[x for x in required if not Path(x).is_file()]
if missing:
 print('STOP: missing required files; nothing packaged:')
 for item in missing: print(' -',item)
 raise SystemExit(2)
with ZipFile(output,'w',ZIP_DEFLATED) as z:
 for path in required:
  p=Path(path)
  # Always place checkpoint under its actual directory name, not absolute location.
  name=(p.parent.name+'/'+p.name) if p.is_absolute() else str(p)
  z.write(p,arcname=name)
 print('Created:',output)
 print('Files included:',len(required))
PYCODE
